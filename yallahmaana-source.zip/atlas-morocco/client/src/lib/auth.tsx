import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'

export type AuthUser = { id: string; firstName: string; lastName: string; email: string; phone: string; verified: boolean; points: number; profileCompletion: number }
type AuthContextValue = { user: AuthUser | null; loading: boolean; error: string | null; login: (email:string,password:string,remember?:boolean)=>Promise<AuthUser>; register: (input:{firstName:string;lastName:string;phone:string;email:string;password:string})=>Promise<AuthUser>; logout: ()=>Promise<void>; forgotPassword: (email:string)=>Promise<void>; clearError: ()=>void }

const sessionKey = 'atlas_session'
const demoUser: AuthUser = { id:'cus_demo_01', firstName:'Yasmine', lastName:'El Amrani', email:'yasmine@example.com', phone:'+212 6 12 34 56 78', verified:true, points:720, profileCompletion:72 }

export const apiClient = {
  async request<T>(path:string, init:RequestInit = {}): Promise<T> {
    const response = await fetch(path, { ...init, headers:{'Content-Type':'application/json', ...(init.headers || {})}, credentials:'include' })
    if (!response.ok) {
      const error = new Error(`API_${response.status}`) as Error & { status?:number }
      error.status = response.status
      throw error
    }
    return response.status === 204 ? (undefined as T) : response.json()
  },
  async login(payload:{email:string;password:string}) { try { return await this.request<AuthUser>('/api/auth/login',{method:'POST',body:JSON.stringify(payload)}) } catch { await new Promise(r=>setTimeout(r,420)); if (!payload.email || !payload.password) throw new Error('INVALID_CREDENTIALS'); if (payload.email.includes('unverified')) throw new Error('EMAIL_NOT_VERIFIED'); return { ...demoUser, email:payload.email } } },
  async register(payload:{firstName:string;lastName:string;phone:string;email:string;password:string}) { try { return await this.request<AuthUser>('/api/auth/register',{method:'POST',body:JSON.stringify(payload)}) } catch { await new Promise(r=>setTimeout(r,420)); return { ...demoUser, firstName:payload.firstName, lastName:payload.lastName, phone:payload.phone, email:payload.email, verified:false, profileCompletion:45 } } },
  async logout() { try { await this.request('/api/auth/logout',{method:'POST'}) } catch { /* frontend demo fallback */ } },
  async forgotPassword(email:string) { try { await this.request('/api/auth/forgot-password',{method:'POST',body:JSON.stringify({email})}) } catch { await new Promise(r=>setTimeout(r,380)) } },
}

const AuthContext = createContext<AuthContextValue | null>(null)
export function AuthProvider({ children }:{children:ReactNode}) {
  const [user,setUser] = useState<AuthUser | null>(null)
  const [loading,setLoading] = useState(true)
  const [error,setError] = useState<string | null>(null)
  useEffect(() => { try { const saved = localStorage.getItem(sessionKey); if (saved) setUser(JSON.parse(saved)) } catch { localStorage.removeItem(sessionKey) } finally { setLoading(false) } },[])
  const persist = (next:AuthUser | null) => { setUser(next); if (next) localStorage.setItem(sessionKey, JSON.stringify(next)); else localStorage.removeItem(sessionKey) }
  const value = useMemo<AuthContextValue>(() => ({ user, loading, error, clearError:()=>setError(null), login:async(email,password,remember=true)=>{ setLoading(true);setError(null); try { const next=await apiClient.login({email,password}); persist(next); if (!remember) sessionStorage.setItem('atlas_session_once','1'); return next } catch (e) { const code=(e as Error).message; const message=code==='EMAIL_NOT_VERIFIED'?'Votre adresse email n’est pas encore vérifiée.':code==='INVALID_CREDENTIALS'?'Email ou mot de passe incorrect.':'Impossible de vous connecter pour le moment. Réessayez.'; setError(message); throw e } finally { setLoading(false) } }, register:async(input)=>{ setLoading(true);setError(null); try { const next=await apiClient.register(input); persist(next); return next } catch (e) { setError('Impossible de créer votre compte pour le moment.'); throw e } finally { setLoading(false) } }, logout:async()=>{ await apiClient.logout(); persist(null) }, forgotPassword:async(email)=>{ await apiClient.forgotPassword(email) } }),[user,loading,error])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
export function useAuth(){ const context=useContext(AuthContext); if(!context) throw new Error('useAuth must be used inside AuthProvider'); return context }
