from pathlib import Path

site=Path('/home/ubuntu/atlas-morocco/client/src/components/site.tsx')
s=site.read_text()
s=s.replace("export function SearchPanel({compact=false}:{compact?:boolean}) { const [destination,setDestination]=useState(''); return", "export function SearchPanel({compact=false}:{compact?:boolean}) { const [destination,setDestination]=useState(''); const [when,setWhen]=useState(''); return")
s=s.replace("<label><span>Quand</span><select><option>Peu importe</option><option>Septembre 2026</option><option>Octobre 2026</option><option>Novembre 2026</option></select></label>", "<label className=\"search-date-field\"><span>Quand</span><input type=\"date\" value={when} onChange={e=>setWhen(e.target.value)} aria-label=\"Choisir une date de départ\"/><small>{when?'Date sélectionnée':'Choisir une date'}</small></label>")
site.write_text(s)

pages=Path('/home/ubuntu/atlas-morocco/client/src/pages/Pages.tsx')
content=pages.read_text()
old="</div><AvailabilityBooking trip={trip}/></div></section><section className=\"section section-sand\"><div className=\"container\"><SectionHeading eyebrow=\"Vous aimerez aussi\" title=\"Continuer l’exploration\"/>"
new="</div><AvailabilityBooking trip={trip}/></div></section><section className=\"section section-sand trip-faq-section\"><div className=\"container faq-layout\"><div><SectionHeading eyebrow=\"QUESTIONS FRÉQUENTES\" title=\"Tout ce qu’il faut savoir avant de partir.\" description=\"Les réponses essentielles pour préparer votre départ sereinement.\"/></div><FAQAccordion items={faqs.slice(0,6)}/></div></section><section className=\"section section-sand\"><div className=\"container\"><SectionHeading eyebrow=\"Vous aimerez aussi\" title=\"Continuer l’exploration\"/>"
if old not in content: raise SystemExit('trip insertion point not found')
content=content.replace(old,new,1)
pages.write_text(content)
