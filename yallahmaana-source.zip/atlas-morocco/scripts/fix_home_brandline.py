from pathlib import Path
p=Path('/home/ubuntu/atlas-morocco/client/src/pages/Pages.tsx')
s=p.read_text()
s=s.replace('<div className="hero-kicker"><span className="eyebrow">Yallahmaana · Morocco</span><span className="line"/><span>Depuis 2019</span></div>','<div className="hero-kicker"><span className="hero-brandline">Yallahmaana <i>· Morocco</i></span><span className="line"/><span className="hero-since">Depuis 2019</span></div>')
p.write_text(s)
