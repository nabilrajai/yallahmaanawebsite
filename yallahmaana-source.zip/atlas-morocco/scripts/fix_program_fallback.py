from pathlib import Path
p=Path('/home/ubuntu/atlas-morocco/client/src/pages/Pages.tsx')
s=p.read_text().replace('${day.tag || }', "${day.tag || ''}")
p.write_text(s)
r=Path('/home/ubuntu/atlas-morocco/client/public/robots.txt')
s=r.read_text().replace('https://atlasandbeyond.ma','https://yallahmaana.com')
r.write_text(s)
