from pathlib import Path
root=Path('/home/ubuntu/atlas-morocco')
logo='/manus-storage/yallahmaana-logo_e62711b1.png'
site=root/'client/src/components/site.tsx'
s=site.read_text()
s=s.replace('<Link href="/" className="brand" aria-label="Yallahmaana, accueil"><span className="brand-mark">A<span>+</span></span><span className="brand-word">atlas <i>& beyond</i></span></Link>',f'<Link href="/" className="brand" aria-label="Yallahmaana, accueil"><img className="brand-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s=s.replace('<Link href="/" className="brand brand-light"><span className="brand-mark">A<span>+</span></span><span className="brand-word">atlas <i>& beyond</i></span></Link>',f'<Link href="/" className="brand brand-light"><img className="brand-logo footer-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s=s.replace('<Link href="/mon-compte" className="drawer-account-link">Mon compte <UserRound size={17}/></Link><Link href="/mon-compte" className="drawer-account-link">Mon compte <UserRound size={17}/></Link>','<Link href="/mon-compte" className="drawer-account-link">Mon compte <UserRound size={17}/></Link>')
s=s.replace('Bonjour%20Atlas%20%26%20Beyond', 'Bonjour%20Yallahmaana')
site.write_text(s)
account=root/'client/src/pages/AccountPages.tsx'
s=account.read_text()
s=s.replace('<Link href="/" className="auth-brand"><span className="brand-mark">A<span>+</span></span><span className="brand-word">atlas <i>& beyond</i></span></Link>',f'<Link href="/" className="auth-brand"><img className="brand-logo auth-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
s=s.replace('<Link href="/" className="auth-brand"><span className="brand-mark">A<span>+</span></span><span className="brand-word">yallahmaana <i>& beyond</i></span></Link>',f'<Link href="/" className="auth-brand"><img className="brand-logo auth-logo" src="{logo}" alt="Yallahmaana.com" /></Link>')
account.write_text(s)
for path in [root/'client/src/pages/Pages.tsx',root/'client/src/components/site.tsx',root/'client/src/pages/AccountPages.tsx']:
 s=path.read_text().replace('Atlas & Beyond','Yallahmaana').replace('atlas & beyond','yallahmaana').replace('ATLAS & BEYOND','YALLAHMAANA')
 path.write_text(s)
