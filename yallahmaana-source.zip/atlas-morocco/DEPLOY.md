# Yallahmaana — guide de déploiement

## Prérequis

- Node.js 18 ou plus récent
- npm 9 ou plus récent
- Un hébergement capable d’exécuter Node.js pour le serveur de production

## Installation et build

```bash
npm install
npm run check
npm run build
```

Le build génère :

- `dist/public/` : fichiers frontend compilés
- `dist/index.js` : serveur Node.js de production

## Démarrage en production

```bash
npm start
```

Le serveur écoute sur la variable d’environnement `PORT` ; si elle n’est pas définie, le port par défaut est `3000`.

Exemple :

```bash
PORT=3000 npm start
```

## Déploiement sur un hébergement Node.js

1. Téléversez et décompressez l’archive.
2. Utilisez Node.js 18+.
3. Lancez `npm install`.
4. Lancez `npm run build`.
5. Configurez la commande de démarrage sur `npm start`.
6. Configurez le document root ou le proxy de l’hébergeur vers le port Node fourni par l’hébergeur.

## Important

- Les images distantes et le logo sont référencés dans le code et doivent rester accessibles depuis votre hébergement.
- Le projet est actuellement une application frontend avec données de démonstration et persistance locale navigateur pour certains parcours.
- Ne téléversez pas `node_modules/` : il est recréé par `npm install`.
